package com.e.agenda.model;

            import java.util.List;

            public class Agenda_pendienteList extends BaseList {
                public List< Agenda_pendiente> data= null;

            }
