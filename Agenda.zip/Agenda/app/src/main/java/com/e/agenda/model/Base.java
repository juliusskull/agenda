package com.e.agenda.model;

public class Base {
 long _id;

public long get_id() {
	return _id;
}

public void set_id(long _id) {
	this._id = _id;
}

}
