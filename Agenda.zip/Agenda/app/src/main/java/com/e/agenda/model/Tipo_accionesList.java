package com.e.agenda.model;

            import java.util.List;

            public class Tipo_accionesList extends BaseList {
                public List< Tipo_acciones> data= null;

            }
