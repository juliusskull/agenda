package com.e.agenda;

import com.e.agenda.adapter.Agenda_pendienteListAdapter;

import com.e.agenda.constants.Configuracion;
import com.e.agenda.db.DatabaseManager;
import com.e.agenda.model.Agenda_pendiente;
import com.e.agenda.model.Agenda_pendienteList;

import com.e.agenda.utils.Util;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class Agenda_pendienteListFrag extends Fragment{
	private ListView lista;
	private Agenda_pendienteListAdapter adapter2;
	protected Agenda_pendienteList list = new Agenda_pendienteList();
	private DatabaseManager dm;

	private static OnListaSelectAgenda_pendiente onListaSelectAgenda_pendiente;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.ppal_list, container,
				false);
		return rootView;
	}
	 @Override
	  public void onActivityCreated(Bundle state) {
	        super.onActivityCreated(state);
			String token= Util.SpGet(getActivity(),Configuracion.BIBLIOTECA, Configuracion.getBiblioClaveApi(),"");
	     	Util.Log("token=>"+token);
		 verLista();

	 }
	 public void verLista(){
		 dm= new DatabaseManager(getActivity());
		 list.data=dm.getAgenda_pendientes();
		 if(list.data!= null && list.data.size()>0){
			 adapter2=new Agenda_pendienteListAdapter(getActivity(),R.layout.usuario_list_item,  list.data);
			 lista=(ListView)getActivity().findViewById(R.id.ppal_list_id);
			 lista.setAdapter(adapter2);
			 lista.setOnItemClickListener(new OnItemClickListener() {
				 @Override
				 public void onItemClick(AdapterView<?> parent, View view,
										 int position, long id) {

					 Agenda_pendienteListFrag.onListaSelectAgenda_pendiente.onClickList(list.data.get(position));
				 }


			 });
		 }

	 }
	 public void setFiltro(String arg0) {
			// TODO Auto-generated method stub
			Util.Log("arg0=>"+arg0);

			adapter2.filter(arg0);
		}
	 public  interface OnListaSelectAgenda_pendiente  {
		    // you can define any parameter as per your requirement
			void onClickList(Agenda_pendiente er);
	}
	public  OnListaSelectAgenda_pendiente getOnListaSelectAgenda_pendiente() {
		return onListaSelectAgenda_pendiente;
	}
	public  void setOnListaSelectAgenda_pendiente(
			OnListaSelectAgenda_pendiente onListaSelectAgenda_pendiente) {
		Agenda_pendienteListFrag.onListaSelectAgenda_pendiente = onListaSelectAgenda_pendiente;
	}


}