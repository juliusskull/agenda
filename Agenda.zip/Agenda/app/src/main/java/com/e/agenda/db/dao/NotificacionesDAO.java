package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.NotificacionesTable;
import com.e.agenda.db.tables.NotificacionesTable.NotificacionesColumns;
import com.e.agenda.model.Notificaciones;
import com.e.agenda.utils.Util;


public class NotificacionesDAO extends DAOBase implements DAO<Notificaciones>{

	private static final String INSERT = "insert into "
			+ NotificacionesTable.TABLE_NAME + "(" + NotificacionesColumns._ID
		    + ", "+ NotificacionesColumns.ID
+ ", "+ NotificacionesColumns.IDPROCESO
+ ", "+ NotificacionesColumns.FECHAALTA
+ ", "+ NotificacionesColumns.FECHAAUTORIZA
+ ", "+ NotificacionesColumns.IDUSUARIOAUTORIZA
+ ", "+ NotificacionesColumns.IDPROCESOAUTORIZA
+ ", "+ NotificacionesColumns.OBSERVACION
+ ", "+ NotificacionesColumns.LEGAJO

			+ ") values (?,?,?,?,?,?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public NotificacionesDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(NotificacionesDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			NotificacionesTable.onCreate(db, null);
			insertStatement = db.compileStatement(NotificacionesDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Notificaciones obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Notificaciones.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ NotificacionesTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindLong(3,  Long.valueOf(data[2]));
insertStatement.bindString(4, data[3]);
insertStatement.bindString(5, data[4]);
insertStatement.bindString(6, data[5]);
insertStatement.bindLong(7,  Long.valueOf(data[6]));
insertStatement.bindString(8, data[7]);
insertStatement.bindLong(9,  Long.valueOf(data[8]));


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(NotificacionesTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Notificaciones getNotificaciones(long id) {
		Notificaciones  place = null;
		String[] columns = NotificacionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(NotificacionesTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Notificaciones();
			place.set_id(c.getLong(0));
             place.setId((int)c.getLong(1));
 place.setIdproceso(c.getLong(2));
 place.setFechaalta(c.getString(3));
 place.setFechaautoriza(c.getString(4));
 place.setIdusuarioautoriza(c.getString(5));
 place.setIdprocesoautoriza(c.getLong(6));
 place.setObservacion(c.getString(7));
 place.setLegajo(c.getLong(8));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Notificaciones[] get(String condition, String[] params) {
		Notificaciones[] Notificaciones = null;
		String[] columns = NotificacionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(NotificacionesTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Notificaciones = new Notificaciones[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Notificaciones[i] = new Notificaciones();
				Notificaciones place = new Notificaciones();
				place.set_id(c.getLong(0));
				  place.setId((int)c.getLong(1));
 place.setIdproceso(c.getLong(2));
 place.setFechaalta(c.getString(3));
 place.setFechaautoriza(c.getString(4));
 place.setIdusuarioautoriza(c.getString(5));
 place.setIdprocesoautoriza(c.getLong(6));
 place.setObservacion(c.getString(7));
 place.setLegajo(c.getLong(8));


				Notificaciones[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Notificaciones;
	}
	@Override
	public Notificaciones get(long id) {

		Notificaciones[] notificaciones = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (notificaciones == null)
			return null;

		return notificaciones[0];
	}




	@Override
	public Notificaciones[] getAll() {
		return null;
	}



}
