package com.e.agenda.model;

            import java.util.List;

            public class NotificacionesList extends BaseList {
                public List< Notificaciones> data= null;

            }
