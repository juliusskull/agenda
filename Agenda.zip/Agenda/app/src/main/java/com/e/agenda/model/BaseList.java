package com.e.agenda.model;

public class BaseList {

    public String status;
    public String code;
    public String msg;
    public String total_items;
    public String pagina_actual;
    public String item_por_pagina;
    public String total_paginas;
}
