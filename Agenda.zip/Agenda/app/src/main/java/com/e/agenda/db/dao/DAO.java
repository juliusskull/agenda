package com.e.agenda.db.dao;

import java.lang.reflect.Field;

import android.database.sqlite.SQLiteStatement;

import com.e.agenda.utils.Util;

public interface DAO<T> {
    long insert(String[] data);

    void remove(long id);

    T get(long id);

    T[] getAll();


}
