package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.Tipo_accionesTable;
import com.e.agenda.db.tables.Tipo_accionesTable.Tipo_accionesColumns;
import com.e.agenda.model.Tipo_acciones;
import com.e.agenda.db.tables.Tipo_accionesTable;
import com.e.agenda.model.Tipo_acciones;
import com.e.agenda.utils.Util;


public class Tipo_accionesDAO extends DAOBase implements DAO<Tipo_acciones>{

	private static final String INSERT = "insert into "
			+ Tipo_accionesTable.TABLE_NAME + "(" + Tipo_accionesColumns._ID
		    + ", "+ Tipo_accionesColumns.CATEGORIA
+ ", "+ Tipo_accionesColumns.ID_ACCION
+ ", "+ Tipo_accionesColumns.DESCRIPCION

			+ ") values (?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public Tipo_accionesDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(Tipo_accionesDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Tipo_accionesTable.onCreate(db, null);
			insertStatement = db.compileStatement(Tipo_accionesDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Tipo_acciones obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Tipo_acciones.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ Tipo_accionesTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindString(2, data[1]);
insertStatement.bindLong(3,  Long.valueOf(data[2]));
insertStatement.bindString(4, data[3]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(Tipo_accionesTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Tipo_acciones getTipo_acciones(long id) {
		Tipo_acciones  place = null;
		String[] columns = Tipo_accionesTable.Tipo_accionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(Tipo_accionesTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Tipo_acciones();
			place.set_id(c.getLong(0));
             place.setCategoria(c.getString(1));
 place.setId_accion((int)c.getLong(2));
 place.setDescripcion(c.getString(3));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Tipo_acciones[] get(String condition, String[] params) {
		Tipo_acciones[] Tipo_acciones = null;
		String[] columns = Tipo_accionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(Tipo_accionesTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Tipo_acciones = new Tipo_acciones[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Tipo_acciones[i] = new Tipo_acciones();
				Tipo_acciones place = new Tipo_acciones();
				place.set_id(c.getLong(0));
				  place.setCategoria(c.getString(1));
 place.setId_accion((int)c.getLong(2));
 place.setDescripcion(c.getString(3));


				Tipo_acciones[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Tipo_acciones;
	}
	@Override
	public Tipo_acciones get(long id) {

		Tipo_acciones[] tipo_acciones = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (tipo_acciones == null)
			return null;

		return tipo_acciones[0];
	}




	@Override
	public Tipo_acciones[] getAll() {
		return null;
	}



}
