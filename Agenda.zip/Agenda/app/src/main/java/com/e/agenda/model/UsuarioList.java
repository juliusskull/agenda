package com.e.agenda.model;

            import java.util.List;

            public class UsuarioList extends BaseList {
                public List< Usuario> data= null;

            }
