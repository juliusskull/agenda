package com.e.agenda.model;

            import java.util.List;

            public class Usuario_accionesList extends BaseList {
                public List< Usuario_acciones> data= null;

            }
