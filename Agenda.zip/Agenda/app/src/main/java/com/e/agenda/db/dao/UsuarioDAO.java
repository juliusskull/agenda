package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.UsuarioTable;
import com.e.agenda.db.tables.UsuarioTable.UsuarioColumns;
import com.e.agenda.model.Usuario;
import com.e.agenda.utils.Util;


public class UsuarioDAO extends DAOBase implements DAO<Usuario>{

	private static final String INSERT = "insert into "
			+ UsuarioTable.TABLE_NAME + "(" + UsuarioColumns._ID
		    + ", "+ UsuarioColumns.IDUSUARIO
+ ", "+ UsuarioColumns.NOMBRE
+ ", "+ UsuarioColumns.CONTRASENA
+ ", "+ UsuarioColumns.CLAVEAPI
+ ", "+ UsuarioColumns.CORREO
+ ", "+ UsuarioColumns.LEGAJO
+ ", "+ UsuarioColumns.IMEI
+ ", "+ UsuarioColumns.PROVISORIA

			+ ") values (?,?,?,?,?,?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public UsuarioDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(UsuarioDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			UsuarioTable.onCreate(db, null);
			insertStatement = db.compileStatement(UsuarioDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Usuario obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Usuario.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ UsuarioTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindString(3, data[2]);
insertStatement.bindString(4, data[3]);
insertStatement.bindString(5, data[4]);
insertStatement.bindString(6, data[5]);
insertStatement.bindLong(7,  Long.valueOf(data[6]));
insertStatement.bindString(8, data[7]);
insertStatement.bindString(9, data[8]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(UsuarioTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Usuario getUsuario(long id) {
		Usuario  place = null;
		String[] columns = UsuarioColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(UsuarioTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Usuario();
			place.set_id(c.getLong(0));
             place.setIdUsuario((int)c.getLong(1));
 place.setNombre(c.getString(2));
 place.setContrasena(c.getString(3));
 place.setClaveApi(c.getString(4));
 place.setCorreo(c.getString(5));
 place.setLegajo((int)c.getLong(6));
 place.setImei(c.getString(7));
 place.setProvisoria(c.getString(8));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Usuario[] get(String condition, String[] params) {
		Usuario[] Usuario = null;
		String[] columns = UsuarioColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(UsuarioTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Usuario = new Usuario[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Usuario[i] = new Usuario();
				Usuario place = new Usuario();
				place.set_id(c.getLong(0));
				  place.setIdUsuario((int)c.getLong(1));
 place.setNombre(c.getString(2));
 place.setContrasena(c.getString(3));
 place.setClaveApi(c.getString(4));
 place.setCorreo(c.getString(5));
 place.setLegajo((int)c.getLong(6));
 place.setImei(c.getString(7));
 place.setProvisoria(c.getString(8));


				Usuario[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Usuario;
	}
	@Override
	public Usuario get(long id) {

		Usuario[] usuario = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (usuario == null)
			return null;

		return usuario[0];
	}




	@Override
	public Usuario[] getAll() {
		return null;
	}



}
