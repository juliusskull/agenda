package com.e.agenda.model;

            import java.util.List;

            public class Agenda_autorizadaList extends BaseList {
                public List< Agenda_autorizada> data= null;

            }
