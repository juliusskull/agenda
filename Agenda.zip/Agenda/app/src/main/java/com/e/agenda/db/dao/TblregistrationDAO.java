package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.TblregistrationTable;
import com.e.agenda.db.tables.TblregistrationTable.TblregistrationColumns;
import com.e.agenda.model.Tblregistration;
import com.e.agenda.utils.Util;


public class TblregistrationDAO extends DAOBase implements DAO<Tblregistration>{

	private static final String INSERT = "insert into "
			+ TblregistrationTable.TABLE_NAME + "(" + TblregistrationColumns._ID
		    + ", "+ TblregistrationColumns.ID
+ ", "+ TblregistrationColumns.REGISTRATION_ID

			+ ") values (?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public TblregistrationDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(TblregistrationDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			TblregistrationTable.onCreate(db, null);
			insertStatement = db.compileStatement(TblregistrationDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Tblregistration obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Tblregistration.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ TblregistrationTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindString(3, data[2]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(TblregistrationTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Tblregistration getTblregistration(long id) {
		Tblregistration  place = null;
		String[] columns = TblregistrationColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(TblregistrationTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Tblregistration();
			place.set_id(c.getLong(0));
             place.setId((int)c.getLong(1));
 place.setRegistration_id(c.getString(2));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Tblregistration[] get(String condition, String[] params) {
		Tblregistration[] Tblregistration = null;
		String[] columns = TblregistrationColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(TblregistrationTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Tblregistration = new Tblregistration[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Tblregistration[i] = new Tblregistration();
				Tblregistration place = new Tblregistration();
				place.set_id(c.getLong(0));
				  place.setId((int)c.getLong(1));
 place.setRegistration_id(c.getString(2));


				Tblregistration[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Tblregistration;
	}
	@Override
	public Tblregistration get(long id) {

		Tblregistration[] tblregistration = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (tblregistration == null)
			return null;

		return tblregistration[0];
	}




	@Override
	public Tblregistration[] getAll() {
		return null;
	}



}
