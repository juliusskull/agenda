package com.e.agenda.model;

            import java.util.List;

            public class TblregistrationList extends BaseList {
                public List< Tblregistration> data= null;

            }
