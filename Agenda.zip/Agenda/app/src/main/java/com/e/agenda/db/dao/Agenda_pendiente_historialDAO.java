package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.Agenda_pendiente_historialTable;
import com.e.agenda.db.tables.Agenda_pendiente_historialTable.Agenda_pendiente_historialColumns;
import com.e.agenda.model.Agenda_pendiente_historial;
import com.e.agenda.utils.Util;


public class Agenda_pendiente_historialDAO extends DAOBase implements DAO<Agenda_pendiente_historial>{

	private static final String INSERT = "insert into "
			+ Agenda_pendiente_historialTable.TABLE_NAME + "(" + Agenda_pendiente_historialColumns._ID
		    + ", "+ Agenda_pendiente_historialColumns.ID
+ ", "+ Agenda_pendiente_historialColumns.IDPROCESO
+ ", "+ Agenda_pendiente_historialColumns.CATEGORIA
+ ", "+ Agenda_pendiente_historialColumns.IDSUBCATEGORIA
+ ", "+ Agenda_pendiente_historialColumns.SUBCATEGORIA
+ ", "+ Agenda_pendiente_historialColumns.IDGESP
+ ", "+ Agenda_pendiente_historialColumns.LEGAJO
+ ", "+ Agenda_pendiente_historialColumns.NUMERO
+ ", "+ Agenda_pendiente_historialColumns.TITULO
+ ", "+ Agenda_pendiente_historialColumns.FCHINGRESO
+ ", "+ Agenda_pendiente_historialColumns.FCHGESTION
+ ", "+ Agenda_pendiente_historialColumns.FCHDESDE
+ ", "+ Agenda_pendiente_historialColumns.FCHHASTA
+ ", "+ Agenda_pendiente_historialColumns.UNIDADMEDIDA
+ ", "+ Agenda_pendiente_historialColumns.MONTO
+ ", "+ Agenda_pendiente_historialColumns.OBSERVACION
+ ", "+ Agenda_pendiente_historialColumns.IDGERENCIA
+ ", "+ Agenda_pendiente_historialColumns.GERENCIA
+ ", "+ Agenda_pendiente_historialColumns.AUTORIZA
+ ", "+ Agenda_pendiente_historialColumns.FCHREGISTRACION

			+ ") values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public Agenda_pendiente_historialDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(Agenda_pendiente_historialDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Agenda_pendiente_historialTable.onCreate(db, null);
			insertStatement = db.compileStatement(Agenda_pendiente_historialDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Agenda_pendiente_historial obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Agenda_pendiente_historial.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ Agenda_pendiente_historialTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindLong(3,  Long.valueOf(data[2]));
insertStatement.bindString(4, data[3]);
insertStatement.bindLong(5,  Long.valueOf(data[4]));
insertStatement.bindString(6, data[5]);
insertStatement.bindLong(7,  Long.valueOf(data[6]));
insertStatement.bindLong(8,  Long.valueOf(data[7]));
insertStatement.bindLong(9,  Long.valueOf(data[8]));
insertStatement.bindString(10, data[9]);
insertStatement.bindString(11, data[10]);
insertStatement.bindString(12, data[11]);
insertStatement.bindString(13, data[12]);
insertStatement.bindString(14, data[13]);
insertStatement.bindString(15, data[14]);
insertStatement.bindString(16, data[15]);
insertStatement.bindString(17, data[16]);
insertStatement.bindLong(18,  Long.valueOf(data[17]));
insertStatement.bindString(19, data[18]);
insertStatement.bindString(20, data[19]);
insertStatement.bindString(21, data[20]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(Agenda_pendiente_historialTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Agenda_pendiente_historial getAgenda_pendiente_historial(long id) {
		Agenda_pendiente_historial  place = null;
		String[] columns = Agenda_pendiente_historialColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(Agenda_pendiente_historialTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Agenda_pendiente_historial();
			place.set_id((int)c.getLong(0));
             place.setId((int)c.getLong(1));
 place.setIdproceso((int)c.getLong(2));
 place.setCategoria(c.getString(3));
 place.setIdsubcategoria((int)c.getLong(4));
 place.setSubcategoria(c.getString(5));
 place.setIdgesp((int)c.getLong(6));
 place.setLegajo((int)c.getLong(7));
 place.setNumero((int)c.getLong(8));
 place.setTitulo(c.getString(9));
 place.setFchingreso(c.getString(10));
 place.setFchgestion(c.getString(11));
 place.setFchdesde(c.getString(12));
 place.setFchhasta(c.getString(13));
 place.setUnidadmedida(c.getString(14));
 place.setMonto(c.getString(15));
 place.setObservacion(c.getString(16));
 place.setIdgerencia((int)c.getLong(17));
 place.setGerencia(c.getString(18));
 place.setAutoriza(c.getString(19));
 place.setFchregistracion(c.getString(20));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Agenda_pendiente_historial[] get(String condition, String[] params) {
		Agenda_pendiente_historial[] Agenda_pendiente_historial = null;
		String[] columns = Agenda_pendiente_historialColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(Agenda_pendiente_historialTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Agenda_pendiente_historial = new Agenda_pendiente_historial[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Agenda_pendiente_historial[i] = new Agenda_pendiente_historial();
				Agenda_pendiente_historial place = new Agenda_pendiente_historial();
				place.set_id((int)c.getLong(0));
				  place.setId((int)c.getLong(1));
 place.setIdproceso((int)c.getLong(2));
 place.setCategoria(c.getString(3));
 place.setIdsubcategoria((int)c.getLong(4));
 place.setSubcategoria(c.getString(5));
 place.setIdgesp((int)c.getLong(6));
 place.setLegajo((int)c.getLong(7));
 place.setNumero((int)c.getLong(8));
 place.setTitulo(c.getString(9));
 place.setFchingreso(c.getString(10));
 place.setFchgestion(c.getString(11));
 place.setFchdesde(c.getString(12));
 place.setFchhasta(c.getString(13));
 place.setUnidadmedida(c.getString(14));
 place.setMonto(c.getString(15));
 place.setObservacion(c.getString(16));
 place.setIdgerencia((int)c.getLong(17));
 place.setGerencia(c.getString(18));
 place.setAutoriza(c.getString(19));
 place.setFchregistracion(c.getString(20));


				Agenda_pendiente_historial[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Agenda_pendiente_historial;
	}
	@Override
	public Agenda_pendiente_historial get(long id) {

		Agenda_pendiente_historial[] agenda_pendiente_historial = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (agenda_pendiente_historial == null)
			return null;

		return agenda_pendiente_historial[0];
	}




	@Override
	public Agenda_pendiente_historial[] getAll() {
		return null;
	}



}
