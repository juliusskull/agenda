package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.Agenda_autorizadaTable;
import com.e.agenda.db.tables.Agenda_autorizadaTable.Agenda_autorizadaColumns;
import com.e.agenda.model.Agenda_autorizada;
import com.e.agenda.utils.Util;


public class Agenda_autorizadaDAO extends DAOBase implements DAO<Agenda_autorizada>{

	private static final String INSERT = "insert into "
			+ Agenda_autorizadaTable.TABLE_NAME + "(" + Agenda_autorizadaColumns._ID
		    + ", "+ Agenda_autorizadaColumns.ID
+ ", "+ Agenda_autorizadaColumns.IDPROCESO
+ ", "+ Agenda_autorizadaColumns.FECHAAUTORIZA
+ ", "+ Agenda_autorizadaColumns.FECHACAD
+ ", "+ Agenda_autorizadaColumns.OBSERVACION
+ ", "+ Agenda_autorizadaColumns.FCHREGISTRACION
+ ", "+ Agenda_autorizadaColumns.IDACCION
+ ", "+ Agenda_autorizadaColumns.CATEGORIA

			+ ") values (?,?,?,?,?,?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public Agenda_autorizadaDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(Agenda_autorizadaDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Agenda_autorizadaTable.onCreate(db, null);
			insertStatement = db.compileStatement(Agenda_autorizadaDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Agenda_autorizada obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Agenda_autorizada.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ Agenda_autorizadaTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindLong(3,  Long.valueOf(data[2]));
insertStatement.bindString(4, data[3]);
insertStatement.bindString(5, data[4]);
insertStatement.bindString(6, data[5]);
insertStatement.bindString(7, data[6]);
insertStatement.bindLong(8,  Long.valueOf(data[7]));
insertStatement.bindString(9, data[8]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(Agenda_autorizadaTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Agenda_autorizada getAgenda_autorizada(long id) {
		Agenda_autorizada  place = null;
		String[] columns = Agenda_autorizadaColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(Agenda_autorizadaTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Agenda_autorizada();
			place.set_id(c.getLong(0));
             place.setId((int)c.getLong(1));
 place.setIdproceso((int)c.getLong(2));
 place.setFechaautoriza(c.getString(3));
 place.setFechacad(c.getString(4));
 place.setObservacion(c.getString(5));
 place.setFchregistracion(c.getString(6));
 place.setIdaccion((int)c.getLong(7));
 place.setCategoria(c.getString(8));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Agenda_autorizada[] get(String condition, String[] params) {
		Agenda_autorizada[] Agenda_autorizada = null;
		String[] columns = Agenda_autorizadaColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(Agenda_autorizadaTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Agenda_autorizada = new Agenda_autorizada[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Agenda_autorizada[i] = new Agenda_autorizada();
				Agenda_autorizada place = new Agenda_autorizada();
				place.set_id(c.getLong(0));
				  place.setId((int)c.getLong(1));
 place.setIdproceso((int)c.getLong(2));
 place.setFechaautoriza(c.getString(3));
 place.setFechacad(c.getString(4));
 place.setObservacion(c.getString(5));
 place.setFchregistracion(c.getString(6));
 place.setIdaccion((int)c.getLong(7));
 place.setCategoria(c.getString(8));


				Agenda_autorizada[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Agenda_autorizada;
	}
	@Override
	public Agenda_autorizada get(long id) {

		Agenda_autorizada[] agenda_autorizada = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (agenda_autorizada == null)
			return null;

		return agenda_autorizada[0];
	}




	@Override
	public Agenda_autorizada[] getAll() {
		return null;
	}



}
