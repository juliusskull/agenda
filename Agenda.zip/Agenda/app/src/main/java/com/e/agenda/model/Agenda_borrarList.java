package com.e.agenda.model;

            import java.util.List;

            public class Agenda_borrarList extends BaseList {
                public List< Agenda_borrar> data= null;

            }
