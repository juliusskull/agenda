package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.Usuario_accionesTable;
import com.e.agenda.db.tables.Usuario_accionesTable.Usuario_accionesColumns;
import com.e.agenda.model.Usuario_acciones;
import com.e.agenda.utils.Util;


public class Usuario_accionesDAO extends DAOBase implements DAO<Usuario_acciones>{

	private static final String INSERT = "insert into "
			+ Usuario_accionesTable.TABLE_NAME + "(" + Usuario_accionesColumns._ID
		    + ", "+ Usuario_accionesColumns.ID
+ ", "+ Usuario_accionesColumns.LEGAJO
+ ", "+ Usuario_accionesColumns.DESCRIPCION
+ ", "+ Usuario_accionesColumns.APLICACION
+ ", "+ Usuario_accionesColumns.VERSION
+ ", "+ Usuario_accionesColumns.FCHALTA

			+ ") values (?,?,?,?,?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public Usuario_accionesDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(Usuario_accionesDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Usuario_accionesTable.onCreate(db, null);
			insertStatement = db.compileStatement(Usuario_accionesDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Usuario_acciones obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Usuario_acciones.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ Usuario_accionesTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindLong(3,  Long.valueOf(data[2]));
insertStatement.bindString(4, data[3]);
insertStatement.bindString(5, data[4]);
insertStatement.bindString(6, data[5]);
insertStatement.bindString(7, data[6]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(Usuario_accionesTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Usuario_acciones getUsuario_acciones(long id) {
		Usuario_acciones  place = null;
		String[] columns = Usuario_accionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(Usuario_accionesTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Usuario_acciones();
			place.set_id(c.getLong(0));
             place.setId((int)c.getLong(1));
 place.setLegajo((int)c.getLong(2));
 place.setDescripcion(c.getString(3));
 place.setAplicacion(c.getString(4));
 place.setVersion(c.getString(5));
 place.setFchalta(c.getString(6));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Usuario_acciones[] get(String condition, String[] params) {
		Usuario_acciones[] Usuario_acciones = null;
		String[] columns = Usuario_accionesColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(Usuario_accionesTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Usuario_acciones = new Usuario_acciones[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Usuario_acciones[i] = new Usuario_acciones();
				Usuario_acciones place = new Usuario_acciones();
				place.set_id(c.getLong(0));
				  place.setId((int)c.getLong(1));
 place.setLegajo((int)c.getLong(2));
 place.setDescripcion(c.getString(3));
 place.setAplicacion(c.getString(4));
 place.setVersion(c.getString(5));
 place.setFchalta(c.getString(6));


				Usuario_acciones[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Usuario_acciones;
	}
	@Override
	public Usuario_acciones get(long id) {

		Usuario_acciones[] usuario_acciones = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (usuario_acciones == null)
			return null;

		return usuario_acciones[0];
	}




	@Override
	public Usuario_acciones[] getAll() {
		return null;
	}



}
