package com.e.agenda.model;

            import java.util.List;

            public class Agenda_pendiente_historialList extends BaseList {
                public List< Agenda_pendiente_historial> data= null;

            }
