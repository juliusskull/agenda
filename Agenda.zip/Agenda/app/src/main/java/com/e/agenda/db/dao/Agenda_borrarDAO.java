package com.e.agenda.db.dao;

import java.lang.reflect.Field;
import java.util.Locale;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.provider.BaseColumns;

import com.e.agenda.db.tables.Agenda_borrarTable;
import com.e.agenda.db.tables.Agenda_borrarTable.Agenda_borrarColumns;
import com.e.agenda.model.Agenda_borrar;
import com.e.agenda.utils.Util;


public class Agenda_borrarDAO extends DAOBase implements DAO<Agenda_borrar>{

	private static final String INSERT = "insert into "
			+ Agenda_borrarTable.TABLE_NAME + "(" + Agenda_borrarColumns._ID
		    + ", "+ Agenda_borrarColumns.IDPROCESO
+ ", "+ Agenda_borrarColumns.FCHALTA

			+ ") values (?,?,?)";

	private SQLiteDatabase db;
	private SQLiteStatement insertStatement;

	public Agenda_borrarDAO(SQLiteDatabase db) {
		this.db = db;
		try {
		    insertStatement = db.compileStatement(Agenda_borrarDAO.INSERT);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Agenda_borrarTable.onCreate(db, null);
			insertStatement = db.compileStatement(Agenda_borrarDAO.INSERT);
			e.printStackTrace();
		}
	}
public long insert2(Agenda_borrar obj) {
		//insertStatement.clearBindings();

		String INSERT2="";
		String INSERT2_P="";
		Field[] fields = Agenda_borrar.class.getDeclaredFields();
		String[] s= new String[fields.length+1];
		int i=0;
		for( Field field : fields ){
			try {

				 if(i>0){
					 INSERT2+=",";
					 INSERT2_P+=",";
				 }
				 INSERT2+=field.getName().toString();
				 INSERT2_P+="?";

				 i++;

			}catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//-----------------
		INSERT2="insert into "+ Agenda_borrarTable.TABLE_NAME +"("+INSERT2+")VALUES("+INSERT2_P+")";
		SQLiteStatement insertStatement2 = db.compileStatement(INSERT2);
		insertStatement2.clearBindings();

		i=0;
		for( Field field : fields ){
			try {
				 field.setAccessible(true);
				 Util.Log("field:"+field.getName().toString()+":"+field.getType().getName());
				 Util.Log("field->:"+field.get(obj));
				 i++;
				 if(field.getType().getName().contains("int") || field.getType().getName().contains("long") ){

					 insertStatement2.bindLong(i,  Long.valueOf( String.valueOf(field.get(obj))));

				 } else{
					 insertStatement2.bindString(i,   String.valueOf( field.get(obj)));
				 }

				} catch (IllegalAccessException e) {

				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			}
		}
		Util.Log("INSERT2->:"+INSERT2);
		return insertStatement2.executeInsert();

	}


	@Override
	public long insert(String[] data) {
		insertStatement.clearBindings();
		insertStatement.bindLong(1, Long.valueOf(data[0]));
		insertStatement.bindLong(2,  Long.valueOf(data[1]));
insertStatement.bindString(3, data[2]);


		return insertStatement.executeInsert();
	}

	@Override
	public void remove(long id) {
		db.delete(Agenda_borrarTable.TABLE_NAME, BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });

	}

	public Agenda_borrar getAgenda_borrar(long id) {
		Agenda_borrar  place = null;
		String[] columns = Agenda_borrarColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db
				.query(Agenda_borrarTable.TABLE_NAME, columns, BaseColumns._ID
						+ " = ?", new String[] { String.valueOf(id) }, null,
						null, null);
		if (c.moveToFirst()) {
			place = new Agenda_borrar();
			place.set_id(c.getLong(0));
             place.setIdproceso((int)c.getLong(1));
 place.setFchalta(c.getString(2));


		}
		if (!c.isClosed()) {
			c.close();
		}
		return place;
	}


	public Agenda_borrar[] get(String condition, String[] params) {
		Agenda_borrar[] Agenda_borrar = null;
		String[] columns = Agenda_borrarColumns.getColumns();
		String language = Locale.getDefault().getLanguage();

		Cursor c = db.query(Agenda_borrarTable.TABLE_NAME, columns, condition,
				params, null, null, null);
		if (c.getCount() == 0) {
			c.close();
			return null;
		}
		if (c.moveToFirst()) {
			Agenda_borrar = new Agenda_borrar[c.getCount()];
			for (int i = 0; i < c.getCount(); i++) {
				Agenda_borrar[i] = new Agenda_borrar();
				Agenda_borrar place = new Agenda_borrar();
				place.set_id(c.getLong(0));
				 place.setIdproceso((int)c.getLong(1));
				 place.setFchalta(c.getString(2));


				Agenda_borrar[i] = place;

				c.moveToNext();
			}
		}
		if (!c.isClosed()) {
			c.close();
		}
		return Agenda_borrar;
	}
	@Override
	public Agenda_borrar get(long id) {

		Agenda_borrar[] agenda_borrar = get(BaseColumns._ID + " = ?",
				new String[] { String.valueOf(id) });
		if (agenda_borrar == null)
			return null;

		return agenda_borrar[0];
	}




	@Override
	public Agenda_borrar[] getAll() {
		return null;
	}



}
